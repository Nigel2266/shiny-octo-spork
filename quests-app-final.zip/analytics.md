# 📊 Analytics Sample

- Total Users: 1
- Quests In Progress: 1
- Quests Completed: 0