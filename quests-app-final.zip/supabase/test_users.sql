-- Insert mock users and quests
INSERT INTO users (email) VALUES ('test@example.com');
INSERT INTO quests (name, targetValue, xpReward) VALUES ('First Quest', 100, 50);